from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')



@app.route('/profileform', methods=['GET','POST'])
def profileForm():
    if request.method == 'POST':
        fname = request.form.get('fname', '').strip()
        lname = request.form.get('lname', '').strip()
        email = request.form.get('email','').strip()
        phone = request.form.get('phone','').strip()
        comments = request.form.get('comments','').strip()
        rel = request.form.get('rel', '').strip()
        accommodations = request.form.get('accommodations') =="yes" # True if checked

        #Validation
        if not fname or not lname or not email or not phone or not rel:
            error = "Please fill in all required fields"
            return  render_template('profileform.html', error=error)

        return render_template(
            'profileSuccess.html',
            fname=fname,
            lname=lname,
            email=email,
            phone=phone,    
            
            comments=comments,
            rel=rel,
            accommodations=accommodations
        )
    return render_template('profileform.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/information')
def information():
    return render_template('information.html')

if __name__ == "__main__":
    app.run(debug=True)