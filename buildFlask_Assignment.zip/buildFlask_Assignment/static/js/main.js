// This JS is loaded on all pages
console.log("Main JS loaded");


function getFor() {
    var name = document.getElementById('firstField').value;
        if (name.trim() === '') {
            alert('Please enter a name');
            return;
        }
        localStorage.setItem('userName', name);
        window.location.href = 'display';
    }

function showName() {
    var name = localStorage.getItem('userName');
        if (name) {
            document.getElementById('displayName').innerHTML ='name';
        } else {
            document.getElementById('displayName').innerHTML = 'No Information provided.';
        }
    }

    showName();